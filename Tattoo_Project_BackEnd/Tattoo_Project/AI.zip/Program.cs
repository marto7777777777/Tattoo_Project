
using Microsoft.EntityFrameworkCore;
using Scalar.AspNetCore;
using Tattoo_Project.Data;
using Tattoo_Project.Services;
using Tattoo_Project.Services.Interfaces;
using Tattoo_Project.AI.Builders;
using Tattoo_Project.AI.Providers;
using Tattoo_Project.AI.Planning;
using Microsoft.AspNetCore.Identity;
using Tattoo_Project.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Stripe;
using Tattoo_Project.Authorization;

namespace Tattoo_Project
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
            builder.Services.AddOpenApi(options =>
            {
                options.AddDocumentTransformer<BearerSecuritySchemeTransformer>();
            });

            builder.Services.AddScoped<IClientService, ClientService>();
            builder.Services.AddScoped<ITattooArtistService, TattooArtistService>();
            builder.Services.AddScoped<IStudioService, StudioService>();
            builder.Services.AddScoped<ITattooRequestService, TattooRequestService>();
            builder.Services.AddScoped<IArtistResponseService, ArtistResponseService>();
            builder.Services.AddScoped<IConsultationService, ConsultationService>();
            builder.Services.AddScoped<ITattooSessionService, TattooSessionService>();
            builder.Services.AddScoped<ITokenService, Tattoo_Project.Services.TokenService>();
            builder.Services.AddScoped<IArtistReviewService, ArtistReviewService>();
            builder.Services.AddScoped<IClientFavoriteStudioService, ClientFavoriteStudioService>();
            builder.Services.AddScoped<IArtistUnavailableDateService, ArtistUnavailableDateService>();
            builder.Services.AddScoped<IProfileService, ProfileService>();
            builder.Services.AddScoped<IAdminService, AdminService>();
            builder.Services.AddScoped<IEmailService, EmailService>();
            builder.Services.AddScoped<IEmailVerificationService, EmailVerificationService>();
            builder.Services.AddScoped<IAiTattooService, AiTattooService>();
            builder.Services.AddScoped<IArtistSubscriptionService, ArtistSubscriptionService>();
            builder.Services.AddScoped<IStripeWebhookService, StripeWebhookService>();
            builder.Services.AddScoped<IAccountDeletionService, AccountDeletionService>();
            builder.Services.AddScoped<IAuthorizationHandler, ActiveArtistSubscriptionHandler>();
            builder.Services.AddAuthorization(options => options.AddPolicy("ActiveArtistSubscription", policy => policy.Requirements.Add(new ActiveArtistSubscriptionRequirement())));
            builder.Services.AddSingleton<IPromptFileProvider, PromptFileProvider>();
            builder.Services.AddScoped<IAiTattooPromptBuilder, AiTattooPromptBuilder>();
            builder.Services.AddScoped<IAiTattooPlanner, AiTattooPlanner>();
            builder.Services.AddHttpClient();
            StripeConfiguration.ApiKey = builder.Configuration["Stripe:SecretKey"];

            builder.Services.AddDbContext<TattooDbContext>(options => 
            options.UseSqlServer(
                builder.Configuration.GetConnectionString("DefaultConnection")));

            builder.Services
                .AddIdentity<ApplicationUser, IdentityRole>(options =>
                {
                    // Email is the account identity and must never be shared by two users.
                    options.User.RequireUniqueEmail = true;
                })
                .AddEntityFrameworkStores<TattooDbContext>()
                .AddDefaultTokenProviders();

            builder.Services
                .AddAuthentication(options =>
                {
                    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,

                        ValidIssuer = builder.Configuration["Jwt:Issuer"],
                        ValidAudience = builder.Configuration["Jwt:Audience"],

                        IssuerSigningKey = new SymmetricSecurityKey(
                            Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!))
                    };
                });

            builder.Services.AddCors(options =>
            {
                options.AddPolicy("ReactApp", policy =>
                {
                    var localOrigins = new[]
                    {
                        "http://localhost:5173",
                        "http://127.0.0.1:5173",
                        "http://172.19.224.1:5173",
                        "http://192.168.33.198:5173"
                    };
                    var configuredOrigins = builder.Configuration
                        .GetSection("Cors:AllowedOrigins")
                        .GetChildren()
                        .Select(item => item.Value?.Trim().TrimEnd('/'))
                        .Where(value => !string.IsNullOrWhiteSpace(value))
                        .Cast<string>();

                    policy
                        .WithOrigins(localOrigins.Concat(configuredOrigins).Distinct(StringComparer.OrdinalIgnoreCase).ToArray())
                        .AllowAnyHeader()
                        .AllowAnyMethod();
                });
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
                app.MapScalarApiReference();
            }

            app.UseHttpsRedirection();

            app.UseCors("ReactApp");

            app.UseStaticFiles();

            app.UseAuthentication();

            app.UseAuthorization();


            app.MapControllers();

            AdminSeedService.EnsureAdminAsync(app.Services, app.Configuration).GetAwaiter().GetResult();

            app.Run();
        }
    }
}
